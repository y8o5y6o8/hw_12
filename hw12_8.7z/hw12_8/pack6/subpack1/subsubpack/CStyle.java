// CStyle.java, ���ɮ׸m��pack6\subpack1\subsubpack��Ƨ���
package pack6.subpack1.subsubpack;
public class CStyle
{
   public int style;

   public CStyle(int n)
   {
       style=n;
       System.out.println("style"+style);
   }
}

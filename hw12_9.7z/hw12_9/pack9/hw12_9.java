// hw12_9.java,���ɮ׸m��pack9��Ƨ���
package pack9;  // �Napp12_8���O�ǤJpackage pack9����
import pack9.sub1.CSphere;// ���Jpack9.sub1�̪�CSphere���O
import pack9.sub2.CTrapezoid;   // ���Jpack9.sub2�̪�CTrapezoid���O

public class hw12_9
{
   public static void main(String args[])  
   {
      CSphere sp=new CSphere(2);
      CTrapezoid tra=new CTrapezoid(2,3,4);
      sp.show();
      tra.show();
   }
}

/* output--------------------------------------------
C:\Documents and Settings\Administrator>cd c:\java
C:\Java>cd hw12_9
C:\Java\hw12_9>javac pack9\sub1\CSphere.java
C:\Java\hw12_9>javac pack9\sub2\CTrapezoid.java
C:\Java\hw12_9>javac pack9\hw12_9.java
C:\Java\hw12_9>java pack9.hw12_9
radius=2.0, volume=33.49333333333333
upper=2, base=3, height=4, area=10.0
--------------------------------------------------*/
// CSphere.java, ���ɮ׸m��hw12_9\pack9\sub1��Ƨ���
package pack9.sub1; // �NCSphere���O�ǤJpack9.sub1��
public class CSphere
{
   final static double PI=3.14;
   private double radius;
   
   public CSphere(double r)
   {
      radius=r;
   }
   public void show()
   {
      double vol=4/3.0*PI*radius*radius*radius;
      
      System.out.print("radius="+radius);
      System.out.println(", volume="+vol);
   }
}